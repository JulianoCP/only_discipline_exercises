
<>COMO EXECUTAR<>

---------------------------------------------------------------
Programa: sum_vector.c
MAKE: make
Executando: 
- Abra o arquivo ./sum_vector em um terminal
---------------------------------------------------------------

