
<>COMO EXECUTAR<>

---------------------------------------------------------------
Programa: read_write_signal.c
MAKE: make
Executando: 
- Abra o arquivo ./read_write_signal em um terminal
---------------------------------------------------------------

