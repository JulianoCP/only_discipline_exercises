
<>COMO EXECUTAR<>

---------------------------------------------------------------
Programa: client.c server.c
MAKE: make
Executando: 
- Abra o arquivo ./server em um terminal (Servidor de comunicação)
    - Abra o arquivo ./client em um terminal separado. (Primeiro jogador)
    - Abra outro arquivo ./client em um terminal separado. (Segundo jogador)

Exemplo de envio de movimentos no tabuleiro do jogo da velha.
    - Apos executar o arquivo ./client em dois terminais diferentes o jogo ira começar.
    - Quando pedir para você fazer um movimento digite da seguinte maneira:

        $ Faça uma jogada: 2 3 

        [ 2 ] - É a linha onde quer fazer sua jogada.
        [ 3 ] - É a coluna onde quer fazer sua jogada.

    Lembre-se de digitar apenas um numero espaço outro numero.
---------------------------------------------------------------

