
<>COMO EXECUTAR<>

---------------------------------------------------------------
Programa: read_fifo.c write_fifo.c
MAKE: make
Executando: 

- Abra o arquivo ./read_fifo em um terminal
- Abra o arquivo ./write_fifo em outro terminal
    Lembre-se de executar o ./write_fifo passando uma string como parametro.
         
       Ex:  ./write_fifo "1 + 1"
---------------------------------------------------------------

